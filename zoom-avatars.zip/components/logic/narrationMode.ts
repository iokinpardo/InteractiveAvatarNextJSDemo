export enum NarrationMode {
  CONVERSATIONAL = "conversational",
  WEBHOOK = "webhook",
}
